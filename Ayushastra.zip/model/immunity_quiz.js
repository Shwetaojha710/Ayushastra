  const { DataTypes } = require("sequelize");
const sequelize = require("../app/connection/connection");
const { duration } = require("moment/moment");

const ImmunityQuiz = sequelize.define('ImmunityQuiz', {
    id: {
      type: DataTypes.BIGINT,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    quiz_type: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: 'Immunity - Mind Body Type 2',
    },
    total_score: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    percentage: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
    result_label: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  }, {
    tableName: 'immunity_quizzes',
    underscored: true,
  });

//   ImmunityQuiz.sync({alter:true})
//   .then(() => {
//     console.log("ImmunityQuiz model synced successfully");
//   })
//   .catch((error) => {
//     console.error("Error syncing ImmunityQuiz model:", error);
//   });

module.exports = ImmunityQuiz;