// controllers/immunityQuizController.js
const ImmunityAnswer = require('../../../model/immunity_answer');
const ImmunityQuestion = require('../../../model/immunity_questions');
const ImmunityQuiz = require('../../../model/immunity_quiz');
const Helper = require('../../helper/helper');


const SCORE_MAP = { never: 0, rarely: 1, often: 2, always: 3 };

// exports.submitImmunityQuiz = async (req, res) => {
//   const t = await sequelize.transaction();
//   try {
//     const { userId, answers } = req.body;
//     if (!answers || !Array.isArray(answers) || answers.length === 0) {
//         return Helper.response(false,'Answers required.',{},res,200)
//     }

//     let totalScore = 0;
//     const processed = answers.map(a => {
//       const key = a.answer.trim().toLowerCase();
//       const score = SCORE_MAP[key] ?? 0;
//       totalScore += score;
//       return { question_id: a.questionId, selected_option: a.answer, score };
//     });

//     const maxScore = answers.length * 3;
//     const percentage = (totalScore / maxScore) * 100;
//     const label =
//       percentage <= 25 ? 'Low immunity' :
//       percentage <= 50 ? 'Below average' :
//       percentage <= 75 ? 'Good' : 'Excellent';

//     const quiz = await ImmunityQuiz.create({
//       user_id: userId || null,
//       total_score: totalScore,
//       percentage,
//       result_label: label,
//     }, { transaction: t });

//     for (const ans of processed) {
//       await ImmunityAnswer.create({ quiz_id: quiz.id, ...ans }, { transaction: t });
//     }

//     await t.commit();
//     return Helper.response(true,'Quiz submitted successfully.', { quizId: quiz.id, result: label, percentage },res,200)
 
//   } catch (err) {
//     await t.rollback();
//     console.error(err,"immunity quiz");
//     return Helper.response(false,err?.message,{},res,500)
//   }
// };



exports.submitImmunityQuiz = async (req, res) => {
  const transaction = await sequelize.transaction();
  try {
    const { answers, data, result } = req.body;

    if (!answers || Object.keys(answers).length === 0) {
      return res.status(400).json({ success: false, message: "Answers are required" });
    }

    const answerArray = Object.values(answers);


    const scoreMap = {
      "Never": 1,
      "Rarely": 2,
      "Often": 3,
      "Always": 4,
      "NEVER": 1,
      "NORMAL": 3,
      "Very Strong": 4,
      "Overweight": 2,
    };

    let totalScore = 0;

  
    const quiz = await ImmunityQuiz.create({
      user_id: null, // Optional if not logged in
      quiz_type: "Immunity - Mind Body Type 2",
      total_score: 0,
      percentage: 0,
      result_label: result || "Pending"
    }, { transaction });

    for (const ans of answerArray) {
      const score = scoreMap[ans.Answer] || 0;
      totalScore += score;

      await ImmunityAnswer.create({
        quiz_id: quiz.id,
        question_id: ans.questionId,
        selected_option: ans.Answer,
        score: score
      }, { transaction });
    }

   
    const maxScore = answerArray.length * 4;
    const percentage = ((totalScore / maxScore) * 100).toFixed(2);

    let resultLabel = result || "Very Low Immunity";
    if (percentage >= 75) resultLabel = "Strong Immunity";
    else if (percentage >= 50) resultLabel = "Moderate Immunity";
    else if (percentage >= 25) resultLabel = "Low Immunity";


    await quiz.update({
      total_score: totalScore,
      percentage,
      result_label: resultLabel
    }, { transaction });

    await transaction.commit();

    return res.status(200).json({
      success: true,
      message: "Immunity Quiz submitted successfully",
      data: {
        quiz_id: quiz.id,
        fullName: data?.fullName || null,
        email: data?.email || null,
        mobile: data?.MobileNumber || data?.mobileNumber || null,
        total_score: totalScore,
        percentage,
        result_label: resultLabel
      }
    });

  } catch (error) {
    await transaction.rollback();
    console.error("Error saving immunity quiz:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message
    });
  }
};