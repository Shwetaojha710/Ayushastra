const Otp = require("../../../model/otp");
const User = require("../../../model/user");
const Address = require("../../../model/address");
const Order = require("../../../model/order");
const OrderItem = require("../../../model/OrderItem");
const Payment = require("../../../model/payment");
const Helper = require("../../helper/helper");
const sequelize = require("../../connection/connection");
const moment = require("moment");
const jwt = require("jsonwebtoken");
const Product = require("../../../model/product");
const registeredUser = require("../../../model/registeredusers");
const { Op } = require("sequelize");
const registered_user = require("../../../model/registeredusers");
const Cart = require("../../../model/cart");
const wishlist = require("../../../model/wishlist");

exports.UserRegistration = async (req, res) => {
  try {
    const data = req.body;
    const {
      firstName,
      lastName,
      email,
      password,
      confirmPassword,
      country,
      mobile,
      termsCheck,
    } = req.body;
    if (
      !mobile ||
      mobile === undefined ||
      mobile === null ||
      mobile === "" ||
      !firstName ||
      !lastName ||
      !email ||
      !password ||
      !termsCheck ||
      !country
    ) {
      return Helper.response(false, "All Fields is required", {}, res, 200);
    }

    const deviceId = req?.headers?.deviceid;

    if (!deviceId || deviceId === undefined || deviceId === "") {
      return Helper.response(false, "Device ID is required", [], res, 400);
    }

    const [ExistsMobile, ExistsEmail] = await Promise.all([
      registeredUser.count({
        where: { mobile, isDeleted:false },
      }),
      registeredUser.count({
        where: { email, isDeleted:false },
      }),
    ]);

    if (ExistsMobile) {
      return Helper.response(
        false,
        "Mobile Number Already Exists",
        {},
        res,
        200
      );
    }
    if (ExistsEmail) {
      return Helper.response(false, "Email Already Exists", {}, res, 200);
    }
    const hashedPassword = Helper.encryptPassword(password);
    const hashedConfirmPassword = Helper.encryptPassword(confirmPassword);

    const CreateUser = await registeredUser.create({
      mobile,
      first_name: firstName,
      last_name: lastName,
      email,
      country,
      constent: termsCheck,
      password: hashedPassword,
      confirmPassword: hashedConfirmPassword,
    });

    if (CreateUser) {
      // await Helper.sendSMS(data.mobile, otps.otp, templateId);
      return Helper.response(
        true,
        "User Registered Successfully",
        {},
        res,
        200
      );
    } else {
      return Helper.response(false, "Unable to Registered User", {}, res, 200);
    }
  } catch (error) {
    console.log(error);
    return Helper.response(false, error?.message, {}, res, 200);
  }
};

exports.Userlogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return Helper.response(
        false,
        "Please provide all required fields",
        {},
        res,
        200
      );
    }
    const user = await registeredUser.findOne({
      where: {
        [Op.or]: [{ email: email.trim() }],
         isDeleted:false
      },
    });

    if (!user) {
      return Helper.response(false, "User not exists!", {}, res, 200);
    }
    if (password.trim() == Helper.decryptPassword(user.password)) {
      let token = jwt.sign(
        { id: user.id, role: user.role },
        process.env.SECRET_KEY,
        {
          expiresIn: "7d",
        }
      );

      const userInfo = await registeredUser.findByPk(user.id);
      userInfo.token = token;
      await userInfo.save();

      const usersData = await registeredUser.findByPk(user.id);
      const address = await Address.findAll({
        where: {
          user_id: usersData.id,
          user_type:'registered_user'
        },
      });
      if (usersData) {
        let data1 = {
          id: usersData.id,
          first_name: usersData.first_name,
          last_name: usersData.last_name,
          mobile: usersData.mobile,
          email: usersData.email,
          token: usersData.token,
          base_url: process.env.BASE_URL,
          profile_image: usersData.profile_image,
          address,
        };
        const responseString = JSON.stringify(data1);
        let encryptedResponse = Helper.encryptPassword(responseString);

        return Helper.response(
          true,
          "You have logged in successfully!",
          data1,
          res,
          200
        );
      } else {
      }
    } else {
      return Helper.response(false, "Invalid Credential", {}, res, 200);
    }
  } catch (error) {
    console.log(error);
    return Helper.response(false, error?.message, {}, res, 200);
  }
};

exports.Userlogout = async (req, res) => {
  const userId = req.users && req.users.id;
  if (!userId) {
    return Helper.response(false, "User ID is required.", [], res, 400);
  }

  try {
    const user = await registeredUser.findByPk(userId);
    if (!user) {
      return Helper.response(false, "User not found.", [], res, 404);
    }

    // Clear the token from the user record
    await user.update({ token: null });

    return Helper.response(
      true,
      "You have logged out successfully!",
      [],
      res,
      200
    );
  } catch (err) {
    console.error("Logout error:", err);
    return Helper.response(false, "Internal server error.", [], res, 500);
  }
};

exports.myOrders = async (req, res) => {
  try {
    const { search = "", page = 1, limit = 10 } = req.body;
    const userId = req.users.id;
    if (!userId) {
      return Helper.response(false, "User ID is required", {}, res, 400);
    }

    const offset = (page - 1) * limit;
    let whereCondition = { user_id: userId, user_type: "registered_user" };

    if (search && search.trim() !== "") {
      whereCondition[Op.or] = [
        { order_no: { [Op.like]: `%${search}%` } },
        { order_status: { [Op.like]: `%${search}%` } },
      ];
    }

    const { count, rows: orders } = await Order.findAndCountAll({
      where: whereCondition,
      order: [["createdAt", "DESC"]],
      limit: Number(limit),
      offset: Number(offset),
    });

    const finalData = await Promise.all(
      orders.map(async (order) => {
        const orderItems = await OrderItem.findAll({
          where: { order_id: order.id },
          raw: true,
        });

        const productNames = await Product.findAll({
          where: {
            id: orderItems.map((item) => item.product_id),
          },
          raw: true,
          attributes: ["product_name", "product_banner_image"],
        });
        // const productNames = orderItems.map(
        //   (item) => item.Product?.name || "Product"
        // );

        let actions = ["View Details"];
        if (order.order_status == "placed") actions.unshift("Write Review");
        if (
          order.order_status == "Processing" ||
          order.order_status == "Shipped"
        )
          actions.unshift("Track Order");
        if (order.order_status == "Cancelled") actions.unshift("Reorder");

        return {
          id: order.id,
          orderId: order.order_no,
          date: moment(order.createdAt).format("YYYY-MM-DD"),
          products: productNames.slice(0, 5),
          status: order.order_status,
          items: productNames.length,
          total: Number(order.total_amount),
          actions,
        };
      })
    );

    if (finalData.length == 0) {
      return Helper.response(false, "No Data Found", [], res, 200);
    }
    return Helper.response(
      true,
      "My Orders fetched successfully",
      {
        page: Number(page),
        totalPages: Math.ceil(count / limit),
        totalOrders: count,
        orders: finalData,
      },
      res,
      200
    );
  } catch (error) {
    console.error("myOrders error:", error);
    return Helper.response(false, error.message, {}, res, 500);
  }
};

exports.viewAddressDetails = async (req, res) => {
  try {
    const { id } = req.body;

    if (!id) {
      return Helper.response(false, "Order ID is required", {}, res, 400);
    }

    // Fetch order
    const order = await Order.findOne({
      where: { id },
      raw: true,
    });

    if (!order) {
      return Helper.response(false, "No Order Found", {}, res, 404);
    }

    // Fetch address
    const address = await Address.findOne({
      where: { id: order.billing_address_id },
      raw: true,
    });

    if (!address) {
      return Helper.response(false, "Address not found", {}, res, 404);
    }

    // Fetch order items
    const orderItems = await OrderItem.findAll({
      where: { order_id: order.id },
      raw: true,
    });

    // Build items with product details
    const items = [];
    for (const item of orderItems) {
      const product = await Product.findOne({
        where: { id: item.product_id },
        raw: true,
      });

      items.push({
        name: product?.product_name || "N/A",
        sku: product?.sku || "N/A",
        qty: item?.quantity || 0,
        price: `₹${item?.total || "0.00"}`,
        image: product?.meta_image || null,
      });
    }

    // Calculate totals
    const subtotal = orderItems.reduce(
      (sum, item) => sum + parseFloat(item.total || 0),
      0
    );
    const shipping = 9.99; // static or configurable
    const tax = +(subtotal * 0.08).toFixed(2); // 8% example
    const total = subtotal + shipping + tax;

    // Final response structure
    const details = {
      paymentMethod: order.payment_method || "Credit Card (**** 7821)",
      shippingMethod: "Standard Shipping (3-5 days)",
      items,
      priceDetails: {
        subtotal: `₹${order?.subtotal}`,
        shipping: `₹${order?.shipping_cost}`,
        tax: `₹${order?.tax}`,
        total: `₹${order?.total_amount}`,
      },
      shippingAddress: {
        name: `${address?.name || ""}`,
        street: address?.address || "",
        apt: address?.address_line2 || "",
        city: `${address?.city || ""}, ${address?.postal_code || ""}`,
        country: address?.country || "",
        phone: address?.mobile || "",
      },
    };

    return Helper.response(
      true,
      "Order details fetched successfully",
      details,
      res,
      200
    );
  } catch (error) {
    console.error("Address error:", error);
    return Helper.response(false, error.message, {}, res, 500);
  }
};

exports.UserAddressDetails = async (req, res) => {
  try {
    const { id } = req.users;

    if (!id) {
      return Helper.response(false, "ID is required", {}, res, 400);
    }

    // Fetch address
    const address = await Address.findAll({
      where: { user_id: id, user_type: "registered_user" },
      raw: true,
      order: [["is_default", "DESC"]],
    });

    if (!address) {
      return Helper.response(false, "Address not found", {}, res, 404);
    }

    const finalData = await Promise.all(
      address.map(async (item) => {
        // const data = await registered_user.findOne({
        //   where: {
        //     id: item?.user_id,
        //     isDeleted:false
        //   },
        // });

        return {
          ...item,
          contact: {
            name: `${item?.full_name}`,
            phone: item?.mobile ?? 0,
          },
        };
      })
    );
   
    if(finalData.length==0){
      return Helper.response(false,"No Data Found",[],res,200)
    }

    return Helper.response(
      true,
      "Address fetched successfully",
      finalData,
      res,
      200
    );
  } catch (error) {
    console.error("Address error:", error);
    return Helper.response(false, error.message, {}, res, 500);
  }
};

exports.UpdateProfile = async (req, res) => {
  try {
    const {
      id,
      first_name,
      last_name,
      email,
      mobile,
      old_password,
      new_password,
      new_confirmPassword,
    } = req.body;

    if (!id || id==undefined) {
      return Helper.response(false, "User ID is required", [], res, 400);
    }

    const RegisterUser = await registered_user.findByPk(id);
    if (!RegisterUser) {
      return Helper.response(false, "User not found", [], res, 404);
    }

 
    if (req.files && req.files.length > 0) {
      if (RegisterUser.profile_image) {
        Helper.deleteFile(RegisterUser.profile_image);
      }
      const file = req.files[0];
      RegisterUser.profile_image = file.filename;
    }


    RegisterUser.first_name = first_name || RegisterUser.first_name;
    RegisterUser.last_name = last_name || RegisterUser.last_name;
    RegisterUser.email = email || RegisterUser.email;
    RegisterUser.mobile = mobile || RegisterUser.mobile;


    if (new_password || new_confirmPassword) {
      if (!old_password) {
        return Helper.response(false, "Old password is required", [], res, 400);
      }

      // const isMatch = await Helper.comparePassword(
      //   old_password,
      //   RegisterUser.password
      // );
      // if (!isMatch) {
      //   return Helper.response(false, "Old password is incorrect", [], res, 400);
      // }

      if (new_password !== new_confirmPassword) {
        return Helper.response(false, "New passwords do not match", [], res, 400);
      }

      const hashedPassword =  Helper.encryptPassword(new_password);
      RegisterUser.password = hashedPassword;
      RegisterUser.confirmPassword = hashedPassword;
    }

    RegisterUser.updatedAt = new Date();

    await RegisterUser.save();

    return Helper.response(
      true,
      "Profile updated successfully",
      RegisterUser,
      res,
      200
    );
  } catch (error) {
    console.error("Error updating user profile:", error);
    Helper.deleteUploadedFiles(req.files);
    return Helper.response(false, error.message, null, res, 500);
  }
};



exports.deleteAccount = async (req, res) => {
  const transaction = await sequelize.transaction(); 
  try {
    const { id } = req.users;

    if (!id) {
      await transaction.rollback();
      return Helper.response(false, "ID is required", [], res, 400);
    }

   
    const user = await registered_user.findByPk(id);
    if (!user) {
      await transaction.rollback();
      return Helper.response(false, "User not found", [], res, 404);
    }


    await registered_user.update(
      { isDeleted: true },
      { where: { id }, transaction }
    );

 
    await Cart.destroy(
      { where: { registeruserId: id }, transaction }
    );

   
    await wishlist.destroy(
      { where: { registeruserId: id }, transaction }
    );

  
    await transaction.commit();

    return Helper.response(true, "Account deleted successfully", {}, res, 200);
  } catch (error) {
    // Rollback transaction in case of any error
    await transaction.rollback();
    console.error("Error deleting account:", error);
    return Helper.response(false, error.message, {}, res, 500);
  }
};


exports.updateAddress = async (req, res) => {
  const transaction = await sequelize.transaction();
  try {
    const {
      id,
    
      full_name,
      mobile,
      address,
      address_line2,
      city,
      state,
      postal_code,
      country,
      address_type,
      is_default
    } = req.body;
  const   user_id=req.users?.id
    // Validate
    if (!id ) {
      await transaction.rollback();
      return Helper.response(false, "Address ID are required", [], res, 400);
    }

    // Check if address exists
    const existingAddress = await Address.findOne({ where: { id, user_id }, transaction });
    if (!existingAddress) {
      await transaction.rollback();
      return Helper.response(false, "Address not found", [], res, 404);
    }

    // If new address is set as default, reset other addresses for the same user
    if (is_default === true) {
      await Address.update(
        { is_default: false },
        { where: { user_id }, transaction }
      );
    }

    // Update address fields
    existingAddress.full_name = full_name || existingAddress.full_name;
    existingAddress.mobile = mobile || existingAddress.mobile;
    existingAddress.address = address || existingAddress.address;
    existingAddress.address_line2 = address_line2 || existingAddress.address_line2;
    existingAddress.city = city || existingAddress.city;
    existingAddress.state = state || existingAddress.state;
    existingAddress.postal_code = postal_code || existingAddress.postal_code;
    existingAddress.country = country || existingAddress.country;
    existingAddress.address_type = address_type || existingAddress.address_type;
    existingAddress.is_default = is_default !== undefined ? is_default : existingAddress.is_default;

    await existingAddress.save({ transaction });

    await transaction.commit();

    return Helper.response(
      true,
      "Address updated successfully",
      existingAddress,
      res,
      200
    );
  } catch (error) {
    await transaction.rollback();
    console.error("Error updating address:", error);
    return Helper.response(false, error.message, {}, res, 500);
  }
};



exports.addAddress = async (req, res) => {
  const transaction = await sequelize.transaction();
  try {
    const {
    
      full_name,
      mobile,
      address,
      address_line2,
      city,
      state,
      postal_code,
      country = "India",
      address_type,
      is_default = false,
    } = req.body;

    const   user_id=req.users?.id
    if (!user_id || !full_name || !mobile || !address || !city || !state || !postal_code) {
      await transaction.rollback();
      return Helper.response(false, "Please provide all required fields", [], res, 400);
    }


    if (is_default === true) {
      await Address.update(
        { is_default: false },
        { where: { user_id ,user_type:'registered_user'}, transaction }
      );
    }


    const newAddress = await Address.create(
      {
        user_id,
        full_name,
        mobile,
        address,
        address_line2,
        city,
        state,
        postal_code,
        country,
        address_type,
        is_default,
        user_type:'registered_user'
      },
      { transaction }
    );

    await transaction.commit();

    return Helper.response(
      true,
      "Address added successfully",
      newAddress,
      res,
      200
    );
  } catch (error) {
    await transaction.rollback();
    console.error("Error adding address:", error);
    return Helper.response(false, error.message, {}, res, 500);
  }
};


exports.deleteAddress=async(req,res)=>{
  try {
    
    const {id}=req.users
    const DeleteAddress=await Address.destroy({
      where:{
        id,
        user_type:'registered_user'
      }
    })
    return Helper.response(true,"Address Deleted Successfulle",DeleteAddress,res,200)

  } catch (error) {
    await transaction.rollback();
    console.error("Error adding address:", error);
    return Helper.response(false, error.message, {}, res, 500);
  }
}